import numpy
import matplotlib.pyplot as plt
import math

from numpy import linalg

class Alternate():
    def __init__(self, model, loss, precision):
        self.model = model
        self.loss = loss

        self.precision = precision

    def optimize(self):
        loss1 = float("inf")
        loss2 = self.loss.f()
        totloss= list()
        while loss1 - loss2 > self.precision:
            
            self._optimize_U_P()
            self._optimize_V()
            self._optimize_b()

            loss1 = loss2
            loss2 = self.loss.f()
            totloss.append(loss2)
        plt.plot(totloss)
    
    
    def _optimize_U_P(self):
        X = self.model.X
        Y = self.model.Y
        
        U = self.model.U
        P = self.model.P
        V = self.model.V

        lambda2 = self.loss.lambda2
        lambda3 = self.loss.lambda3
        lambda4 = self.loss.lambda4
        lambda5 = self.loss.lambda5
        
        L = numpy.sum(numpy.power(X @ V, 2)) + lambda2 * numpy.sum(numpy.power(Y @ P, 2)) + (1+lambda4) * numpy.sum(numpy.power(Y, 2))
        
        k = 0
        
        P1 = self.model.P
        P2 = self.model.P
        
        U1 = self.model.U
        U2 = self.model.U
        
        loss1 = self.loss.f()
        loss2 = self.loss.f()
        
        for _ in range(100):
            if loss1 - loss2 > self.precision * 10:
                break
            #更新P
            self.model.P = P2 + k / (k + 3) * (P2 - P1)

            dP = self.loss.dP()

            Z = self.model.P - dP / L

            #k += 1
            P1 = P2
            P2 = numpy.copysign(numpy.maximum(numpy.abs(Z) - lambda5 / L, 0), Z)
            P2 = numpy.maximum(P2, 0)
            # P2 = P2 / numpy.sqrt(numpy.sum(numpy.power(P2, 2), 0))
            self.model.P = P2
            
            #更新U
            self.model.U = U2 + k / (k + 3) * (U2 - U1)

            dU = self.loss.dU()

            Z = self.model.U - dU / L

            k += 1
            U1 = U2
            U2 = numpy.copysign(numpy.maximum(numpy.abs(Z) - lambda3 / L, 0), Z)
            U2 = U2 / numpy.sqrt(numpy.sum(numpy.power(U2, 2), 0))
            self.model.U = U2

            loss1 = loss2
            loss2 = self.loss.f()

    def _optimize_V(self):
        X = self.model.X
        Y = self.model.Y

        P = self.model.P
        U = self.model.U
        b = self.model.b

        lambda1 = self.loss.lambda1

        w, W = linalg.eigh(X.T @ X)
        q, Q = linalg.eigh(U @ U.T)

        w = w.reshape(w.shape[0], 1)
        q = q.reshape(q.shape[0], 1)

        H = w @ q.T + lambda1
        M = W.T @ X.T @ (Y @ P - b.T) @ U.T @ Q

        I = numpy.abs(H) < 1e-10
        M[I] = 0
        H[I] = 1

        self.model.V = W @ (M / H) @ Q.T

    def _optimize_b(self):
        X = self.model.X
        Y = self.model.Y
        
        P = self.model.P
        U = self.model.U
        V = self.model.V

        self.model.b = numpy.mean(Y @ P - X @ V @ U, 0).reshape(self.model.b.shape)
