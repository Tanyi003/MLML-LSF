import numpy

from numpy import random

class Linear():
    def __init__(self, X, Y, d):
        self.X = X
        self.Y = Y

        m = X.shape[1]
        l = Y.shape[1]

        self.P = random.randn(l, l).astype(numpy.float32)
        self.U = random.randn(d, l).astype(numpy.float32)
        self.V = random.randn(m, d).astype(numpy.float32)
        self.b = random.randn(l, 1).astype(numpy.float32)
        
        
        #self.P = self.P / numpy.sqrt(numpy.sum(numpy.power(self.P, 2), 0))
        self.U = self.U / numpy.sqrt(numpy.sum(numpy.power(self.U, 2), 0))

    def predict(self, X):
        Y = self.output(X)
        Y[Y >= 0.5] = 1
        Y[Y <= 0.5] = 0
        return Y

    def output(self, X):
        Y = X @ self.V @ self.U + self.b.T
        return Y
