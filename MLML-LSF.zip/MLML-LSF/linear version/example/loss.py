import numpy

class Wrap():
    def __init__(self, model, lambda1, lambda2, lambda3, lambda4, lambda5):
        self.model = model

        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.lambda3 = lambda3
        self.lambda4 = lambda4
        self.lambda5 = lambda5
          
          
    def f(self):
        X = self.model.X
        Y = self.model.Y

        P = self.model.P
        U = self.model.U
        V = self.model.V
        b = self.model.b


        lambda1 = self.lambda1
        lambda2 = self.lambda2
        lambda3 = self.lambda3
        lambda4 = self.lambda4
        lambda5 = self.lambda5

        #C = - Y.T @ Y
        #C[range(Y.shape[1]), range(Y.shape[1])] = 0

        C = numpy.diag(numpy.sum(P,axis=1)) - P
        
        loss = 0
        loss += numpy.sum(numpy.power(X @ V @ U + b.T - Y @ P, 2)) / 2
        loss += lambda1 * numpy.sum(numpy.power(V, 2)) / 2
        loss += lambda2 * numpy.trace(U @ C @ U.T) / 2
        loss += lambda3 * numpy.sum(numpy.abs(U))
        loss += lambda4 * numpy.sum(numpy.power(Y @ P - Y , 2)) / 2
        loss += lambda5 * numpy.sum(numpy.abs(P))
    
        return loss

    def dU(self):
        X = self.model.X
        Y = self.model.Y

        P = self.model.P
        U = self.model.U
        V = self.model.V
        b = self.model.b

        lambda2 = self.lambda2
        C = numpy.diag(numpy.sum(P,axis=1)) - P
        #C = - Y.T @ Y
        #C[range(Y.shape[1]), range(Y.shape[1])] = 0

        XV = X @ V

        dU = XV.T @ (XV @ U + b.T - Y @ P) + lambda2 * U @ C

        return dU
    
    def dP(self):
        X = self.model.X
        Y = self.model.Y

        P = self.model.P
        U = self.model.U
        V = self.model.V
        b = self.model.b

        lambda4 = self.lambda4

        XV = X @ V

        dP = Y.T @ ((1+lambda4) * Y @ P - XV @ U - b.T -  lambda4 * Y) 

        return dP
