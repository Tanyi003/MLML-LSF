# -*- coding: utf-8 -*-
"""
Created on Wed Jul  7 20:59:32 2021

@author: g310
"""

import numpy
from scipy.io import loadmat
m = loadmat(".//data//emotion.mat")
test_data = m['test_data']

test_target = m['test_target'].T
train_data  = m['train_data']

train_target = m['train_target'].T

test_target[test_target==-1]=0
train_target[train_target==-1]=0

#train_data.append(test_data)
x = numpy.vstack((train_data, test_data))
y = numpy.vstack((train_target,test_target))

#b.expandtabs()
#e[e==-1]=0