import numpy
import time
class Wrap():
    def __init__(self, model, lambda1, lambda2, lambda3, lambda4, lambda5):
        self.model = model

        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.lambda3 = lambda3
        self.lambda4 = lambda4
        self.lambda5 = lambda5

    def f(self):
        Y = self.model.Y

        K = self.model.K
        M = self.model.M
        A = self.model.A
        U = self.model.U
        b = self.model.b

        lambda1 = self.lambda1
        lambda2 = self.lambda2
        lambda3 = self.lambda3
        lambda4 = self.lambda4
        lambda5 = self.lambda5

        #C = - Y.T @ Y
        #C[range(Y.shape[1]), range(Y.shape[1])] = 0
        C = numpy.diag(numpy.sum(M,axis=1)) - M

        loss = 0
        
        # print('时间：', time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        loss += numpy.sum(numpy.power(K @ A @ U + b.T - Y @ M, 2)) / 2
        # print('时间：', time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        
        loss += lambda1 * numpy.sum(numpy.trace(A.T @ K @ A)) / 2
        loss += lambda2 * numpy.trace(U @ C @ U.T) / 2
        loss += lambda3 * numpy.sum(numpy.abs(U))
        loss += lambda4 * numpy.sum(numpy.power(Y @ M - Y, 2)) / 2
        loss += lambda5 * numpy.sum(numpy.abs(M))
        return loss

    def dU(self):
        Y = self.model.Y

        K = self.model.K
        M = self.model.M
        A = self.model.A
        U = self.model.U
        b = self.model.b

        lambda2 = self.lambda2

        #C = - Y.T @ Y
        #C[range(Y.shape[1]), range(Y.shape[1])] = 0
        C = numpy.diag(numpy.sum(M,axis=1)) - M

        KA = K @ A

        dU = KA.T @ (KA @ U + b.T - Y @ M) + lambda2 * U @ C

        return dU
    
    def dM(self):
        Y = self.model.Y

        K = self.model.K
        M = self.model.M
        A = self.model.A
        U = self.model.U
        b = self.model.b

        lambda4 = self.lambda4

        #C = - Y.T @ Y
        #C[range(Y.shape[1]), range(Y.shape[1])] = 0
        # C = numpy.diag(numpy.sum(M,axis=1)) - M

        KA = K @ A
        
        dM = Y.T @ ((1+lambda4) * Y @ M - KA @ U - b.T -  lambda4 * Y) 

        return dM
