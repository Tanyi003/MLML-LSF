import numpy
# import time
from numpy import random

class Kernelized():
    def __init__(self, X, Y, d, kernel):
        self.X = X
        self.Y = Y

        self.kernel = kernel

        n = (X.shape[0] + Y.shape[0]) // 2
        m = X.shape[1]
        l = Y.shape[1]
        # ticks1 = time.time()
        # print ("当前时间戳为:", ticks1)
        # print('时间：', time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        self.K = kernel.K(X, X)
        self.M = random.randn(l, l).astype(numpy.float32)
        self.A = random.randn(n, d).astype(numpy.float32)
        self.U = random.randn(d, l).astype(numpy.float32)
        self.b = random.randn(l, 1).astype(numpy.float32)
        # ticks2 = time.time()
        # print ("kenel当前时间戳为:", ticks2)
        # print('时间：', time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        # print ("当前时间差为:", (ticks2-ticks1))
        self.U = self.U / numpy.sqrt(numpy.sum(numpy.power(self.U, 2), 0))

    def predict(self, X):
        Y = self.output(X)
        Y[Y >= 0.5] = 1
        Y[Y <= 0.5] = 0
        return Y

    def output(self, X):
        Y = self.kernel.K(X, self.X) @ self.A @ self.U + self.b.T
        return Y
