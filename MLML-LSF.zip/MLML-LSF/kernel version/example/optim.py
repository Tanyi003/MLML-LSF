import numpy
import matplotlib.pyplot as plt
from numpy import linalg

class Alternate():
    def __init__(self, model, loss, precision):
        self.model = model
        self.loss = loss

        self.precision = precision

        self.p, self.P = linalg.eigh(self.model.K)

    def optimize(self):
        totloss= list()
        loss1 = float("inf")
        loss2 = self.loss.f()
        while loss1 - loss2 > self.precision:
            self._optimize_U_M()
            self._optimize_A()
            self._optimize_b()

            loss1 = loss2
            loss2 = self.loss.f()
            totloss.append(loss2)
        plt.plot(totloss)


    def _optimize_U_M(self):
        Y = self.model.Y

        K = self.model.K
        A = self.model.A
        M = self.model.M

        lambda2 = self.loss.lambda2
        lambda3 = self.loss.lambda3
        
        lambda4 = self.loss.lambda4
        lambda5 = self.loss.lambda5

        L = numpy.sum(numpy.power(K @ A, 2)) + lambda2 * numpy.sum(numpy.power(Y @ M, 2)) +(1 + lambda4) * numpy.sum(numpy.power(Y, 2))

        k = 0
        
        U1 = self.model.U
        U2 = self.model.U
        
        M1 = self.model.M
        M2 = self.model.M
        
        loss1 = self.loss.f()
        # loss1 = float("inf")
        loss2 = self.loss.f()
        # index = 0
        
        # while loss1 - loss2 > self.precision * 10:
        for _ in range(100):
            if loss1 - loss2 > self.precision * 10:
                break
            self.model.M = M2 + k / (k + 3) * (M2 - M1)
            dM = self.loss.dM()
            Z = self.model.M - dM / L
            M1 = M2
            M2 = numpy.maximum(numpy.abs(Z) - lambda5 / L, 0)
            M2 = numpy.maximum(M2, 0)

            self.model.M = M2
            
            self.model.U = U2 + k / (k + 3) * (U2 - U1)
            dU = self.loss.dU()
            Z = self.model.U - dU / L
            k += 1
            U1 = U2
            
            U2 = numpy.copysign(numpy.maximum(numpy.abs(Z) - lambda3 / L, 0), Z)
            U2 = U2 / numpy.sqrt(numpy.sum(numpy.power(U2, 2), 0))
            self.model.U = U2

            loss1 = loss2
            loss2 = self.loss.f()

    def _optimize_U(self):
        Y = self.model.Y

        K = self.model.K
        A = self.model.A
        M = self.model.M

        lambda2 = self.loss.lambda2
        lambda3 = self.loss.lambda3
        
        # lambda4 = self.loss.lambda4
        # lambda5 = self.loss.lambda5

        L = numpy.sum(numpy.power(K @ A, 2)) + lambda2 * numpy.sum(numpy.power(Y @ M, 2))

        k = 0
        
        U1 = self.model.U
        U2 = self.model.U
        
        # M1 = self.model.M
        # M2 = self.model.M
        
        loss1 = float("inf")
        loss2 = self.loss.f()
        while loss1 - loss2 > self.precision * 10:
            for _ in range(100):
                # self.model.M = M2 + k / (k + 3) * (M2 - M1)
                # dM = self.loss.dM()
                # Z = self.model.M - dM / L
                # M1 = M2
                # M2 = numpy.copysign(numpy.maximum(numpy.abs(Z) - lambda5 / L, 0), Z)
                # M2 = numpy.maximum(M2, 0)
                # M2 = M2 / numpy.sqrt(numpy.sum(numpy.power(M2, 2), 0))
                # self.model.M = M2
                
                self.model.U = U2 + k / (k + 3) * (U2 - U1)
                dU = self.loss.dU()
                Z = self.model.U - dU / L
                k += 1
                U1 = U2
                
                U2 = numpy.copysign(numpy.maximum(numpy.abs(Z) - lambda3 / L, 0), Z)
                U2 = U2 / numpy.sqrt(numpy.sum(numpy.power(U2, 2), 0))
                self.model.U = U2

            loss1 = loss2
            loss2 = self.loss.f()



    def _optimize_A(self):
        Y = self.model.Y

        K = self.model.K
        M = self.model.M
        U = self.model.U
        b = self.model.b

        lambda1 = self.loss.lambda1

        p, P = self.p, self.P
        q, Q = linalg.eigh(U @ U.T)

        p = p.reshape(p.shape[0], 1)
        q = q.reshape(q.shape[0], 1)

        H = p * p @ q.T + lambda1 * p
        R = p * P.T @ (Y @ M- b.T) @ U.T @ Q

        I = numpy.abs(H) < 1e-10
        H[I] = 1
        R[I] = 0

        self.model.A = P @ (R / H) @ Q.T

    def _optimize_b(self):
        Y = self.model.Y

        K = self.model.K
        M = self.model.M
        A = self.model.A
        U = self.model.U

        self.model.b = numpy.mean(Y @ M- K @ A @ U, 0).reshape(self.model.b.shape)
