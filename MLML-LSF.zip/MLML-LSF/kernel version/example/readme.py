import os
import sys

current_path = sys.path[0]
sys.path.append(os.path.split(current_path)[0])

import arff
import numpy
from scipy.io import loadmat
import random
import core
import kernel
import measure

from sklearn import model_selection
from sklearn import preprocessing

def getIncompleteTarget(target, percent):
    obsTarget_index = numpy.ones(target.shape)
    totoalNum = sum(sum(target ==1))
    totoaldeleteNum = 0
    N = target.shape[0]
    realpercent = 0
    maxIteration = 50
    factor = 2
    count=0
    while realpercent < percent:
        if maxIteration == 0:
            factor = 1;
            maxIteration = 10
            if count==1:
                break;
            count = count + 1
        else:
            maxIteration = maxIteration - 1
        for i in range(0,N-1): 
            index = numpy.argwhere(target[i]==1)
            index = index.T
            if index.shape[1] >= factor:
                deleteNum = numpy.round(1 + numpy.random.rand(1,1)*(index.shape[1] - 1))
                totoaldeleteNum = totoaldeleteNum + deleteNum
                realpercent = totoaldeleteNum/totoalNum
                if realpercent >= percent:
                    break
                if deleteNum > 0:
                    index = index[0][numpy.array(random.sample([i for i in range(index.shape[1])],index.shape[1]))]
                    d=(deleteNum[0][0]-1)
                    d=d.astype(numpy.int32)
                    target[i][index[0:d]] = 0
                    obsTarget_index[i][index[1:d]]=0
    print('\nTotoal Number of Labeled Entities : %d\n '%totoalNum) 
    print('Number of Deleted Labeled Entities : %d\n '%totoaldeleteNum)
    print('Given percent/Real percent : %.2f / %.4f\n' %(percent,totoaldeleteNum/totoalNum))
    return target

def load():
    
    file = loadmat(".//datalift//emotion.mat")
    test_data = file['test_data']
    test_target = file['test_target'].T
    train_data = file['train_data']
    train_target = file['train_target'].T
    test_target[test_target==-1]=0
    train_target[train_target==-1]=0
    X = numpy.vstack((train_data, test_data))
    Y = numpy.vstack((train_target, test_target))
    X = X / numpy.sqrt(numpy.sum(numpy.power(X, 2), 0))
    
    

    X = preprocessing.scale(X)

    return X, Y

def main(alpha, lambda1, lambda2, lambda3, lambda4, lambda5, kernel):
    X, Y = load()

    hamming_loss = list()
    coverage = list()
    ranking_loss = list()
    one_error = list()
    average_precision = list()
    macro_averaging_auc = list()
    
    
    cross = model_selection.KFold(n_splits = 5, shuffle = True)
    for train, test in cross.split(X, Y):
        target = getIncompleteTarget(Y[train],0.40)
        train = X[train], target
        test = X[test], Y[test]

        P, O = core.run(train, test, alpha, lambda1, lambda2, lambda3, lambda4, lambda5, kernel)

        hamming_loss.append(measure.hamming_loss(test[1], P, O))
        coverage.append(measure.coverage(test[1], P, O))
        ranking_loss.append(measure.ranking_loss(test[1], P, O))
        one_error.append(measure.one_error(test[1], P, O))
        average_precision.append(measure.average_precision(test[1], P, O))
        macro_averaging_auc.append(measure.macro_averaging_auc(test[1], P, O))
        

    file = open( "result.txt", "a")
    
    
    file.write(" hamming_loss： " + str(numpy.mean(numpy.array(hamming_loss)).item()) + " +- ")
    file.write(str(numpy.std(numpy.array(hamming_loss), ddof = 1).item()) + "\n")
    
    file.write(" one_error： " + str(numpy.mean(numpy.array(one_error)).item()) + " +- ")
    file.write(str(numpy.std(numpy.array(one_error), ddof = 1).item()) + "\n")
    
    file.write(" coverage： " + str(numpy.mean(numpy.array(coverage)).item()) + " +- ")
    file.write(str(numpy.std(numpy.array(coverage), ddof = 1).item()) + "\n")
    
    file.write(" average_precision： " + str(numpy.mean(numpy.array(average_precision)).item()) + " +- ")
    file.write(str(numpy.std(numpy.array(average_precision), ddof = 1).item()) + "\n")
    
    file.write(" ranking_loss： " + str(numpy.mean(numpy.array(ranking_loss)).item()) + " +- ")
    file.write(str(numpy.std(numpy.array(ranking_loss), ddof = 1).item()) + "\n")
    

    
    
    file.close()

if __name__ == "__main__":
    for _ in range(1):
        main(0.9, 1, 0.1, 0.1, 30, 0.1 ,kernel.Gaussian(1024))

