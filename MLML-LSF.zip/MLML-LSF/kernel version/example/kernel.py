import numpy

class Gaussian():
    def __init__(self, sigma2):
        self.sigma2 = sigma2

    def K(self, X1, X2):
        n1 = X1.shape[0]
        n2 = X2.shape[0]

        d1 = numpy.sum(numpy.power(X1, 2), 1).reshape(n1, 1)
        d2 = numpy.sum(numpy.power(X2, 2), 1).reshape(n2, 1)

        K = numpy.exp(- (d1 + d2.T - 2 * X1 @ X2.T) / (2 * self.sigma2))

        return K
